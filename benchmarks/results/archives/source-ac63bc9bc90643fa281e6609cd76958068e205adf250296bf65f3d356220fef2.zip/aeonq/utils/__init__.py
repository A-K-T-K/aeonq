"""Numerical and reproducibility utilities."""

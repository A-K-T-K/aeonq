"""Numerical and reproducibility utilities."""

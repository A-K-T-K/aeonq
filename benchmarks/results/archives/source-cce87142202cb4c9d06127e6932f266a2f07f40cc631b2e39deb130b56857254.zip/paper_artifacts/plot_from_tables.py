"""Redraw every paper figure from result files already on disk.

No experiment, SDK or estimator runs here: inputs are the generated tables,
processed CSVs, raw trial JSONL and small JSON files. Change styling in
``figure_style.py`` and rerun this script; it takes seconds. Figures carry no
titles; their captions are in ``figure_captions.md``.

    python paper_artifacts/plot_from_tables.py              # all figures
    python paper_artifacts/plot_from_tables.py --only 5 11  # just these
    python paper_artifacts/plot_from_tables.py --formats pdf png

Inputs (relative to paper_artifacts/):
  1-2   architecture.json
  3, 7  raw_results/<reference profile>.jsonl (per-trial estimates and schedules)
  4,5,9 processed_results/summary.csv
  6     raw_results/phase10_compiler.csv
  8     raw_results/alias_stress.json
  10    processed_results/operator_conformance.csv
  11    tables/table_9_native_baselines.csv
  12    tables/table_13_noise.csv
  13    tables/table_11_scaling.csv
  14    tables/table_12_adapter_mutation.csv
"""

import argparse
import csv
import json
import math
from pathlib import Path
import textwrap
from typing import Any, Callable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

import figure_style as style

ROOT = Path(__file__).resolve().parent
OUTSIDE_RIGHT = {"loc": "upper left", "bbox_to_anchor": (1.01, 1.0), "borderaxespad": 0}


# Reading ------------------------------------------------------------------


def _csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def _num(value: Any) -> float | None:
    if value in (None, "", "None", "nan"):
        return None
    return float(value)


def _reference_profile(root: Path) -> str:
    last_run = root / "environment" / "last_run.json"
    profile = (
        json.loads(last_run.read_text(encoding="utf-8")).get(
            "profile", "publication_reference"
        )
        if last_run.exists()
        else "publication_reference"
    )
    return {"smoke": "smoke_reference"}.get(profile, profile)


def _trials(path: Path) -> list[dict]:
    """Only the per-trial fields the figures use; skips a truncated last line."""
    rows = []
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            result = row.get("result")
            if not result:
                continue
            rows.append(
                {
                    "method": row["method_label"],
                    "algorithm": row["algorithm"],
                    "case_id": row["case_id"],
                    "trial": row["trial"],
                    "a_true": row["a_true"],
                    "estimate": result["estimate"],
                    "queries": result["total_oracle_queries"],
                    "powers": result["powers_used"],
                }
            )
    return rows


# Helpers ------------------------------------------------------------------


def _figure(rows: int = 1, columns: int = 1, **kwargs: Any) -> tuple[Any, Any]:
    return plt.subplots(rows, columns, figsize=style.figure_size(), **kwargs)


def _save(
    fig: Any,
    out: Path,
    number: int,
    name: str,
    formats: tuple[str, ...],
    rect: tuple[float, float, float, float] | None = None,
) -> None:
    # tight_layout keeps the fixed 16:9 page; a tight bounding box would not.
    fig.tight_layout(rect=rect, pad=0.4)
    for extension in formats:
        fig.savefig(out / f"figure_{number:02d}_{name}.{extension}", dpi=style.DPI)
    plt.close(fig)


def _reference_line(ax: Any, y: float, **kwargs: Any) -> None:
    kwargs.setdefault("color", style.REFERENCE_LINE)
    kwargs.setdefault("linestyle", "--")
    ax.axhline(y, linewidth=style.REFERENCE_LINE_WIDTH, **kwargs)


def _end_labels(
    ax: Any, items: list[tuple[float, float, str]], gap_points: float = 8
) -> None:
    """Direct labels at line ends, nudged vertically so none overlap."""
    if not items:
        return
    ax.figure.canvas.draw()
    scale = 72 / ax.figure.dpi
    placed = sorted(
        (
            (ax.transData.transform((x, y))[1] * scale, x, y, text)
            for x, y, text in items
        ),
        key=lambda item: item[0],
    )
    previous = None
    for anchor, x, y, text in placed:
        target = anchor if previous is None else max(anchor, previous + gap_points)
        ax.annotate(
            text,
            (x, y),
            xytext=(4, target - anchor),
            textcoords="offset points",
            va="center",
            fontsize=style.LABEL_SIZE,
            color=style.INK_SECONDARY,
        )
        previous = target


def _facets(count: int, columns: int = 4) -> tuple[Any, list[Any]]:
    columns = min(columns, count)
    rows = (count + columns - 1) // columns
    fig, grid = _figure(rows, columns, squeeze=False, sharex=True, sharey=True)
    axes = [ax for row in grid for ax in row]
    for ax in axes[count:]:
        ax.set_visible(False)
    return fig, axes[:count]


def _outer_labels(axes: list[Any], xlabel: str, ylabel: str) -> None:
    for ax in axes:
        spec = ax.get_subplotspec()
        if spec.is_last_row() or not any(
            other.get_subplotspec().rowspan.start == spec.rowspan.stop
            and other.get_subplotspec().colspan.start == spec.colspan.start
            for other in axes
        ):
            ax.set_xlabel(xlabel)
            ax.tick_params(labelbottom=True)
        if spec.is_first_col():
            ax.set_ylabel(ylabel)


def _bernoulli_order(case: str) -> tuple:
    if case.startswith("bernoulli_"):
        return (0, float(case.split("_", 1)[1]), case)
    return (1, 0.0, case)


# Figures 1-10 -------------------------------------------------------------


def figure_diagrams(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    """Six-stage flows as a two-row snake: left to right, down, right to left."""
    architecture = json.loads((root / "architecture.json").read_text(encoding="utf-8"))
    for number, key, name in (
        (1, "figure_1", "architecture"),
        (2, "figure_2", "pipeline"),
    ):
        labels = architecture[key]
        per_row = (len(labels) + 1) // 2
        fig, ax = _figure()
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis("off")
        boxes = []
        for i, label in enumerate(labels):
            row, position = divmod(i, per_row)
            column = position if row == 0 else per_row - 1 - position
            boxes.append(
                ax.text(
                    (column + 0.5) / per_row,
                    0.66 if row == 0 else 0.34,
                    textwrap.fill(label, 18),
                    ha="center",
                    va="center",
                    fontsize=style.BASE_FONT_SIZE + 1,
                    color=style.INK,
                    bbox={
                        "boxstyle": "round,pad=0.6",
                        "facecolor": style.DIAGRAM_FILL,
                        "edgecolor": style.DIAGRAM_EDGE,
                        "linewidth": style.AXIS_WIDTH,
                    },
                )
            )
        fig.canvas.draw()
        arrow = {
            "arrowstyle": "-|>",
            "color": style.INK_SECONDARY,
            "linewidth": style.AXIS_WIDTH,
            "shrinkA": 9,
            "shrinkB": 9,
        }
        for i in range(1, len(boxes)):
            same_row = (i - 1) // per_row == i // per_row
            first_row = i < per_row
            if same_row and first_row:
                start, end = (1, 0.5), (0, 0.5)
            elif same_row:
                start, end = (0, 0.5), (1, 0.5)
            else:
                start, end = (0.5, 0), (0.5, 1)
            ax.annotate(
                "",
                xy=end,
                xycoords=boxes[i],
                xytext=start,
                textcoords=boxes[i - 1],
                arrowprops=arrow,
            )
        _save(fig, out, number, name, formats)


def figure_error_queries(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    profile = _reference_profile(root)
    trials = _trials(root / "raw_results" / f"{profile}.jsonl")
    methods = sorted({t["method"] for t in trials})
    fig, axes = _facets(len(methods))
    for index, (ax, method) in enumerate(zip(axes, methods)):
        rows = [t for t in trials if t["method"] == method]
        ax.scatter(
            [t["queries"] for t in rows],
            [max(1e-12, abs(t["estimate"] - t["a_true"])) for t in rows],
            s=style.SCATTER_SIZE,
            alpha=style.SCATTER_ALPHA,
            color=style.SERIES[0],
            linewidths=0,
            rasterized=style.RASTERIZE_DENSE,
        )
        ax.set(xscale="log", yscale="log")
        style.style_axes(ax)
        style.panel_label(ax, index, method)
    _outer_labels(axes, "A/A† queries", "Absolute error")
    _save(fig, out, 3, "error_queries", formats)


def _reference_summary(root: Path) -> list[dict]:
    profile = _reference_profile(root)
    return [
        r
        for r in _csv(root / "processed_results" / "summary.csv")
        if r["backend"] == "reference"
        and r["profile"] == profile
        and (_num(r.get("n")) or 0) > 0
    ]


def figure_rmse_shots(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    summary = _reference_summary(root)
    methods = sorted({r["method"] for r in summary})
    fig, axes = _facets(len(methods))
    for index, (ax, method) in enumerate(zip(axes, methods)):
        rows = [r for r in summary if r["method"] == method]
        ax.scatter(
            [_num(r["mean_shots"]) for r in rows],
            [_num(r["rmse"]) for r in rows],
            s=style.SCATTER_SIZE * 2.5,
            color=style.SERIES[0],
            linewidths=0,
        )
        ax.set(xscale="log")
        style.style_axes(ax)
        style.panel_label(ax, index, method)
    _outer_labels(axes, "Mean total shots", "RMSE")
    _save(fig, out, 4, "rmse_shots", formats)


def figure_coverage(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    rows = [r for r in _reference_summary(root) if (_num(r.get("coverage_n")) or 0) > 0]
    methods = sorted({r["method"] for r in rows})
    fig, ax = _figure()
    for index, method in enumerate(methods):
        selected = [r for r in rows if r["method"] == method]
        ax.scatter(
            [index] * len(selected),
            [_num(r["empirical_coverage"]) for r in selected],
            color=style.SERIES[0],
            alpha=style.SCATTER_ALPHA,
            s=style.SCATTER_SIZE * 3,
            linewidths=0,
            label="Coverage per problem" if index == 0 else None,
        )
        lowest = min(selected, key=lambda r: _num(r["empirical_coverage"]))
        observed = _num(lowest["empirical_coverage"])
        ax.errorbar(
            index + 0.12,
            observed,
            yerr=[
                [observed - _num(lowest["coverage_wilson_lower"])],
                [_num(lowest["coverage_wilson_upper"]) - observed],
            ],
            fmt=style.MARKERS[1],
            color=style.SERIES[1],
            capsize=2,
            elinewidth=style.LINE_WIDTH,
            markersize=style.MARKER_SIZE,
            label="Lowest problem, 95% Wilson interval" if index == 0 else None,
        )
    if rows:
        _reference_line(ax, _num(rows[0]["nominal_coverage"]), label="Nominal coverage")
    low = min((_num(r["coverage_wilson_lower"]) for r in rows), default=0.0)
    ax.set(ylim=(max(0.0, low - 0.02), 1.005), ylabel="Empirical coverage")
    ax.set_xticks(range(len(methods)), methods, rotation=20, ha="right")
    style.style_axes(ax)
    style.legend(ax, loc="lower left")
    _save(fig, out, 5, "coverage", formats)


def figure_compiler(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    rows = _csv(root / "raw_results" / "phase10_compiler.csv")
    # AE-aware last and hollow: it coincides with ordinary SDK compilation,
    # and drawing it on top keeps that overlap visible instead of hiding it.
    pipelines = sorted({r["pipeline"] for r in rows}, key=lambda p: p == "ae_aware")
    cases = sorted({r["case_id"] for r in rows})
    fig, axes = _figure(1, 2)
    for c, case in enumerate(cases):
        for p, pipeline in enumerate(pipelines):
            selected = sorted(
                (r for r in rows if r["case_id"] == case and r["pipeline"] == pipeline),
                key=lambda r: int(r["power"]),
            )
            powers = [int(r["power"]) for r in selected]
            hollow = pipeline == "ae_aware"
            for ax, column in zip(axes, ("depth", "two_qubit_gates")):
                ax.plot(
                    powers,
                    [_num(r[column]) for r in selected],
                    color=style.SERIES[p],
                    marker=style.MARKERS[p],
                    markerfacecolor="none" if hollow else style.SERIES[p],
                    markersize=style.MARKER_SIZE + (2.5 if hollow else 0),
                    linestyle=style.LINESTYLES[c % len(style.LINESTYLES)],
                    linewidth=style.LINE_WIDTH,
                    label=f"{case}: {pipeline.replace('_', ' ')}",
                )
    axes[0].set(xlabel="Grover power $k$", ylabel="Compiled depth")
    axes[1].set(xlabel="Grover power $k$", ylabel="Two-qubit gates")
    for index, ax in enumerate(axes):
        ax.set_yscale("symlog", linthresh=1)
        style.style_axes(ax)
        style.panel_label(ax, index, ("depth", "two-qubit gates")[index])
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, frameon=False)
    _save(fig, out, 6, "compiler_resources", formats, rect=(0, 0.16, 1, 1))


def figure_schedule(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    profile = _reference_profile(root)
    trials = [
        t
        for t in _trials(root / "raw_results" / f"{profile}.jsonl")
        if t["algorithm"] == "iqae"
        and t["case_id"] == "bernoulli_0.25"
        and t["trial"] == 0
    ]
    fig, ax = _figure()
    for slot, trial in enumerate(sorted(trials, key=lambda t: t["method"])):
        powers = trial["powers"]
        ax.plot(
            range(1, len(powers) + 1),
            powers,
            color=style.SERIES[slot],
            marker=style.MARKERS[slot],
            linewidth=style.LINE_WIDTH,
            markersize=style.MARKER_SIZE,
            label=trial["method"],
        )
    ax.set(xlabel="Circuit evaluation", ylabel="Grover power $k$")
    style.style_axes(ax)
    if trials:
        style.legend(ax, **OUTSIDE_RIGHT)
    _save(fig, out, 7, "schedule", formats)


def figure_alias(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    alias = json.loads(
        (root / "raw_results" / "alias_stress.json").read_text(encoding="utf-8")
    )
    observations = alias["observations"]
    fig, ax = _figure()
    ax.plot(
        range(1, len(observations) + 1),
        [r["successes"] / r["shots"] for r in observations],
        color=style.SERIES[0],
        marker=style.MARKERS[0],
        linewidth=style.LINE_WIDTH,
        markersize=style.MARKER_SIZE,
        label="Observed good-state fraction",
    )
    ax.axvline(
        2,
        color=style.SERIES[1],
        linestyle="--",
        linewidth=style.REFERENCE_LINE_WIDTH,
        label="Injected incompatible observation",
    )
    ax.set(xlabel="Circuit evaluation", ylabel="Observed good-state fraction")
    style.style_axes(ax)
    style.legend(ax, loc="best")
    _save(fig, out, 8, "alias_stress", formats)


def figure_boundary(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    summary = _reference_summary(root)
    fig, ax = _figure()
    for slot, method in enumerate(sorted({r["method"] for r in summary})):
        rows = sorted(
            (
                r
                for r in summary
                if r["method"] == method and r["case_id"].startswith("bernoulli_")
            ),
            key=lambda r: _num(r["a_true"]),
        )
        ax.plot(
            [_num(r["a_true"]) for r in rows],
            [_num(r["mae"]) for r in rows],
            color=style.SERIES[slot % len(style.SERIES)],
            marker=style.MARKERS[slot % len(style.MARKERS)],
            linewidth=style.LINE_WIDTH,
            markersize=style.MARKER_SIZE,
            label=method,
        )
    ax.set(xlabel="True amplitude $a$", ylabel="Mean absolute error")
    style.style_axes(ax)
    style.legend(ax, **OUTSIDE_RIGHT)
    _save(fig, out, 9, "boundary", formats)


def figure_conformance(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    rows = _csv(root / "processed_results" / "operator_conformance.csv")
    backends = sorted({r["backend"] for r in rows})
    distances = [
        max(_num(r["exact_distance"]) for r in rows if r["backend"] == b)
        for b in backends
    ]
    fig, ax = _figure()
    ax.bar(
        backends, [max(1e-16, d) for d in distances], color=style.SERIES[0], width=0.55
    )
    _reference_line(ax, 1e-9, label="Qiskit, Cirq and PennyLane tolerance")
    _reference_line(
        ax, 1e-6, color=style.SERIES[1], linestyle=":", label="QDK dump tolerance"
    )
    ax.set(yscale="log", ylabel="Maximum exact operator distance")
    style.style_axes(ax)
    style.legend(ax, loc="upper left")
    _save(fig, out, 10, "cross_sdk_conformance", formats)


# Figures 11-14 ------------------------------------------------------------


NATIVE_METHOD_NAMES = {
    "iqae": "Iterative",
    "mlqae": "Maximum likelihood",
    "faster_ae": "Faster",
    "canonical_qae": "Canonical",
}


# library: (legend label, colour, marker, hollow). Only each library's default
# interval is drawn; the likelihood-ratio sensitivity check on the same
# qiskit-algorithms MLAE runs (library "qiskit_algorithms_lr") is reported in
# the tables and text, not in the figure.
NATIVE_SERIES = {
    "aeonq": ("aeonq", style.SERIES[0], style.MARKERS[0], False),
    "qiskit_algorithms": (
        "qiskit-algorithms",
        style.SERIES[1],
        style.MARKERS[1],
        False,
    ),
}


def _problem_label(case: str) -> str:
    """Tick text: amplitudes near 0 and 1 as powers of ten, cases by size."""
    if case.startswith("lognormal_tail_"):
        return "case " + case.removeprefix("lognormal_tail_").split("_")[0]
    a = float(case.removeprefix("bernoulli_"))
    if 0 < a < 1e-3:
        return rf"$10^{{{round(math.log10(a))}}}$"
    if 1 - 1e-3 < a < 1:
        return rf"$1-10^{{{round(math.log10(1 - a))}}}$"
    return f"{a:g}"


def figure_native(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    table = _csv(root / "tables" / "table_9_native_baselines.csv")
    rows = [r for r in table if _num(r.get("coverage")) is not None]
    # Table 3 order, canonical last. A note replaces a library with no interval.
    methods = [m for m in NATIVE_METHOD_NAMES if any(r["method"] == m for r in table)]
    cases = sorted({r["case_id"] for r in table}, key=_bernoulli_order)
    fig, axes = _facets(len(methods), columns=2)
    for index, (ax, method) in enumerate(zip(axes, methods)):
        # Alternate bands group each problem's aeonq / qiskit-algorithms pair.
        for position in range(0, len(cases), 2):
            ax.axvspan(
                position - 0.5, position + 0.5, color=style.GRID, alpha=0.35, lw=0
            )
        if not any(r["method"] == method and r["library"] == "aeonq" for r in rows):
            ax.text(
                0.5,
                0.42,
                "aeonq reports no interval for this estimator\n"
                "(point estimate only); only qiskit-algorithms is shown",
                transform=ax.transAxes,
                ha="center",
                va="center",
                fontsize=style.LABEL_SIZE,
                color=style.INK_SECONDARY,
            )
        libraries = [
            library
            for library in NATIVE_SERIES
            if any(r["method"] == method and r["library"] == library for r in rows)
        ]
        for slot, library in enumerate(libraries):
            label, colour, marker, hollow = NATIVE_SERIES[library]
            selected = {
                r["case_id"]: r
                for r in rows
                if r["method"] == method and r["library"] == library
            }
            present = [c for c in cases if c in selected]
            ys = [_num(selected[c]["coverage"]) for c in present]
            offset = (slot - (len(libraries) - 1) / 2) * 0.27
            ax.errorbar(
                [cases.index(c) + offset for c in present],
                ys,
                # Clamped: at coverage 0 or 1 the Wilson bound differs from the
                # point by rounding only (about 1e-18), which errorbar rejects.
                yerr=[
                    [
                        max(0.0, y - _num(selected[c]["coverage_wilson_lower"]))
                        for c, y in zip(present, ys)
                    ],
                    [
                        max(0.0, _num(selected[c]["coverage_wilson_upper"]) - y)
                        for c, y in zip(present, ys)
                    ],
                ],
                fmt=marker,
                color=colour,
                markerfacecolor="none" if hollow else colour,
                markersize=style.MARKER_SIZE - 0.5,
                elinewidth=style.LINE_WIDTH * 0.8,
                capsize=0,
                label=label,
            )
        _reference_line(ax, 0.95)
        ax.set_xlim(-0.5, len(cases) - 0.5)
        ax.set_xticks(
            range(len(cases)),
            [_problem_label(c) for c in cases],
            rotation=45,
            ha="right",
            rotation_mode="anchor",
            fontsize=style.TICK_SIZE - 1,
        )
        style.style_axes(ax)
        ax.grid(False, axis="x")
        style.panel_label(ax, index, NATIVE_METHOD_NAMES[method])
    _outer_labels(axes, "Problem (Bernoulli amplitude a, or case study)", "Coverage")
    legend: dict[str, Any] = {}
    for ax in axes:
        for handle, label in zip(*ax.get_legend_handles_labels()):
            legend.setdefault(label, handle)
    fig.legend(
        legend.values(), legend.keys(), loc="upper center", ncol=2, frameon=False
    )
    _save(fig, out, 11, "native_baseline_coverage", formats, rect=(0, 0, 1, 0.94))


def figure_noise(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    rows = _csv(root / "tables" / "table_13_noise.csv")
    methods = sorted({r["method"] for r in rows})
    cases = sorted({r["case_id"] for r in rows})
    fig, axes = _figure(1, len(methods), sharey=True, squeeze=False)
    axes = axes[0]
    rates = sorted({_num(r["one_qubit_error"]) for r in rows})
    noisy = [rate for rate in rates if rate > 0]
    # The ideal simulator (rate 0) is drawn one decade left of the smallest
    # noisy rate and labelled "ideal" instead of a fictitious rate.
    ideal_x = noisy[0] / 10
    for index, (ax, method) in enumerate(zip(axes, methods)):
        for slot, case in enumerate(cases):
            selected = sorted(
                (r for r in rows if r["method"] == method and r["case_id"] == case),
                key=lambda r: _num(r["one_qubit_error"]),
            )
            xs = [_num(r["one_qubit_error"]) or ideal_x for r in selected]
            ys = [_num(r["coverage"]) for r in selected]
            ax.plot(
                xs,
                ys,
                color=style.SERIES[slot],
                marker=style.MARKERS[slot],
                markersize=style.MARKER_SIZE,
                linewidth=style.LINE_WIDTH,
                label=case.replace("lognormal_tail_", ""),
            )
        _reference_line(ax, 0.95)
        ax.set_xscale("log")
        ax.set_xlim(ideal_x / 1.6, noisy[-1] * 1.6)
        ax.set_xticks([ideal_x, *noisy])
        ax.set_xticklabels(["ideal", *(f"{rate:g}" for rate in noisy)])
        ax.minorticks_off()
        ax.set_xlabel("One-qubit depolarizing rate")
        style.style_axes(ax)
        style.panel_label(ax, index, method)
    axes[0].set_ylabel("Interval coverage")
    style.legend(axes[0], loc="lower left")
    _save(fig, out, 12, "noise_coverage", formats)


def figure_scaling(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    rows = [
        r
        for r in _csv(root / "tables" / "table_11_scaling.csv")
        if r["status"] == "ok" and r["power"] == "16"
    ]
    fig, ax = _figure()
    for slot, backend in enumerate(dict.fromkeys(r["backend"] for r in rows)):
        selected = sorted(
            (r for r in rows if r["backend"] == backend), key=lambda r: int(r["qubits"])
        )
        ax.plot(
            [int(r["qubits"]) for r in selected],
            [_num(r["compile_seconds"]) + _num(r["execute_seconds"]) for r in selected],
            color=style.SERIES[slot],
            marker=style.MARKERS[slot],
            markersize=style.MARKER_SIZE,
            linewidth=style.LINE_WIDTH,
            label=backend,
        )
    ax.set_yscale("log")
    ax.set(
        xlabel="Qubits (uniform threshold problem, $k = 16$)",
        ylabel="Lower, compile and 1000 shots (s)",
    )
    style.style_axes(ax)
    style.legend(ax, **OUTSIDE_RIGHT)
    _save(fig, out, 13, "scaling", formats)


def figure_mutation(root: Path, out: Path, formats: tuple[str, ...]) -> None:
    rows = [
        r
        for r in _csv(root / "tables" / "table_12_adapter_mutation.csv")
        if r["mutant"] != "none"
    ]
    levels = (
        "failed_operator_checks",
        "failed_measurement_checks",
        "failed_sampling_checks",
    )
    values = [[int(r[level]) for level in levels] for r in rows]
    peak = max(max(v) for v in values) or 1
    steps = len(style.SEQUENTIAL) - 2
    fig, ax = _figure()
    for i, row in enumerate(values):
        for j, value in enumerate(row):
            step = 0 if value == 0 else 1 + min(steps, int(steps * value / peak))
            ax.add_patch(
                plt.Rectangle(
                    (j, i),
                    0.97,
                    0.9,
                    facecolor=style.SEQUENTIAL[step],
                    edgecolor=style.GRID if step == 0 else "none",
                    linewidth=style.GRID_WIDTH,
                )
            )
            ax.text(
                j + 0.485,
                i + 0.45,
                str(value),
                ha="center",
                va="center",
                fontsize=style.LABEL_SIZE,
                color="#ffffff" if step >= steps else style.INK,
            )
    ax.set_xlim(0, 3)
    ax.set_ylim(len(rows), 0)
    ax.set_xticks(
        [0.485, 1.485, 2.485],
        ["Operator (exact)", "Measurement (basis states)", "Sampling (G-test)"],
    )
    ax.xaxis.tick_top()
    ax.set_yticks(
        [i + 0.45 for i in range(len(rows))],
        [r["mutant"].replace("_", " ") for r in rows],
    )
    ax.tick_params(length=0, colors=style.INK)
    for spine in ax.spines.values():
        spine.set_visible(False)
    _save(fig, out, 14, "mutation_detection", formats)


FIGURES: dict[int, tuple[Callable[[Path, Path, tuple[str, ...]], None], str]] = {
    1: (figure_diagrams, "architecture.json"),
    3: (figure_error_queries, "raw_results"),
    4: (figure_rmse_shots, "processed_results/summary.csv"),
    5: (figure_coverage, "processed_results/summary.csv"),
    6: (figure_compiler, "raw_results/phase10_compiler.csv"),
    7: (figure_schedule, "raw_results"),
    8: (figure_alias, "raw_results/alias_stress.json"),
    9: (figure_boundary, "processed_results/summary.csv"),
    10: (figure_conformance, "processed_results/operator_conformance.csv"),
    11: (figure_native, "tables/table_9_native_baselines.csv"),
    12: (figure_noise, "tables/table_13_noise.csv"),
    13: (figure_scaling, "tables/table_11_scaling.csv"),
    14: (figure_mutation, "tables/table_12_adapter_mutation.csv"),
}


def plot(
    root: Path = ROOT,
    out: Path | None = None,
    only: set[int] | None = None,
    formats: tuple[str, ...] | None = None,
) -> list[int]:
    """Draw the requested figures whose inputs exist; return the numbers drawn."""
    style.apply_global()
    out = out or root / "figures"
    out.mkdir(parents=True, exist_ok=True)
    formats = formats or style.FORMATS
    drawn = []
    for number, (draw, needed) in FIGURES.items():
        wanted = only is None or number in only or (number == 1 and 2 in only)
        if wanted and (root / needed).exists():
            draw(root, out, formats)
            drawn.extend([1, 2] if number == 1 else [number])
    return drawn


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument(
        "--root", type=Path, default=ROOT, help="paper_artifacts directory"
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=None,
        help="figure directory (default: <root>/figures)",
    )
    parser.add_argument("--only", type=int, nargs="*", help="figure numbers to draw")
    parser.add_argument(
        "--formats", nargs="*", help="override figure_style.FORMATS, e.g. pdf png"
    )
    arguments = parser.parse_args()
    drawn = plot(
        arguments.root,
        arguments.out,
        set(arguments.only) if arguments.only else None,
        tuple(arguments.formats) if arguments.formats else None,
    )
    print("drew figures", drawn)

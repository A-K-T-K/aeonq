"""Every visual setting for the paper figures, in one place.

Edit this file and run ``python paper_artifacts/plot_from_tables.py`` to redraw
all figures in seconds from files already on disk; no experiment is rerun.

Journal style: vector PDF with embedded TrueType fonts, Times New Roman,
16:9 at double-column width, no figure titles (captions live in
``figure_captions.md``), thin axes and outward ticks.

Palette note: SERIES is a validated categorical order (adjacent-pair
colour-vision-deficiency and normal-vision separation checked with the dataviz
validator). Keep its order if you add series; scatter-style charts should use
at most the first three slots. Every series also carries a marker shape, so
figures stay readable in greyscale print.
"""

from typing import Any

import matplotlib.pyplot as plt

# Output -------------------------------------------------------------------
FORMATS = ("pdf",)
DPI = 600  # only affects rasterized dense scatter layers inside the PDF
RASTERIZE_DENSE = True  # per-trial scatter clouds as images, axes stay vector

# Size: every figure is exactly 16:9 ----------------------------------------
FIGURE_WIDTH = 7.0  # inches; about 17.8 cm, a typical double-column width
ASPECT = 16 / 9

# Type ---------------------------------------------------------------------
FONT_FAMILY = "serif"
SERIF_FONTS = [
    "Times New Roman",
    "Times",
    "Liberation Serif",
    "Nimbus Roman",
    "DejaVu Serif",
]
MATH_FONTSET = "stix"  # Times-compatible mathematics
BASE_FONT_SIZE = 8
TICK_SIZE = 7
LEGEND_SIZE = 7
LABEL_SIZE = 7  # direct labels at line ends and cell values
PANEL_LABELS = True  # "(a) name" above each panel of multi-panel figures
PANEL_LABEL_SIZE = 8

# Colour -------------------------------------------------------------------
SERIES = (
    "#2a78d6",
    "#eb6834",
    "#1baf7a",
    "#eda100",
    "#e87ba4",
    "#008300",
    "#4a3aa7",
    "#e34948",
)
MARKERS = ("o", "s", "^", "D", "v", "P", "X", "*")
LINESTYLES = ("-", "--", ":", "-.")
SURFACE = "#ffffff"
INK = "#000000"
INK_SECONDARY = "#333333"
MUTED = "#7a7a7a"
GRID = "#e6e6e6"
AXIS = "#000000"
REFERENCE_LINE = MUTED  # nominal-coverage and tolerance lines
SEQUENTIAL = ("#ffffff", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b")
DIAGRAM_FILL = "#e8f0fb"
DIAGRAM_EDGE = "#1c5cab"

# Marks --------------------------------------------------------------------
LINE_WIDTH = 1.0
REFERENCE_LINE_WIDTH = 0.8
MARKER_SIZE = 3.5
SCATTER_SIZE = 5
SCATTER_ALPHA = 0.45
AXIS_WIDTH = 0.6
GRID_WIDTH = 0.4
SHOW_GRID = True
HIDE_TOP_RIGHT_SPINES = False  # False: every plot is boxed on all four sides


def figure_size() -> tuple[float, float]:
    return (FIGURE_WIDTH, FIGURE_WIDTH / ASPECT)


def apply_global() -> None:
    """Matplotlib defaults shared by every figure."""
    plt.rcParams.update(
        {
            "font.family": FONT_FAMILY,
            "font.serif": SERIF_FONTS,
            "mathtext.fontset": MATH_FONTSET,
            "font.size": BASE_FONT_SIZE,
            "axes.labelsize": BASE_FONT_SIZE,
            "axes.titlesize": PANEL_LABEL_SIZE,
            "xtick.labelsize": TICK_SIZE,
            "ytick.labelsize": TICK_SIZE,
            "legend.fontsize": LEGEND_SIZE,
            "axes.linewidth": AXIS_WIDTH,
            "xtick.major.width": AXIS_WIDTH,
            "ytick.major.width": AXIS_WIDTH,
            "xtick.minor.width": AXIS_WIDTH * 0.7,
            "ytick.minor.width": AXIS_WIDTH * 0.7,
            "xtick.major.size": 3,
            "ytick.major.size": 3,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "lines.linewidth": LINE_WIDTH,
            "figure.facecolor": SURFACE,
            "savefig.facecolor": SURFACE,
            "savefig.dpi": DPI,
            "pdf.fonttype": 42,  # embed TrueType, never Type 3
            "ps.fonttype": 42,
            "legend.frameon": False,
        }
    )


def style_axes(ax: Any) -> None:
    ax.set_facecolor(SURFACE)
    ax.grid(SHOW_GRID, color=GRID, linewidth=GRID_WIDTH)
    ax.set_axisbelow(True)
    for side in ("top", "right", "left", "bottom"):
        ax.spines[side].set_visible(
            not (HIDE_TOP_RIGHT_SPINES and side in ("top", "right"))
        )
        ax.spines[side].set_color(AXIS)
        ax.spines[side].set_linewidth(AXIS_WIDTH)
    ax.tick_params(colors=INK)
    ax.xaxis.label.set_color(INK)
    ax.yaxis.label.set_color(INK)


def panel_label(ax: Any, index: int, text: str) -> None:
    """A short "(a) name" identifier above a panel; not a figure title."""
    if PANEL_LABELS:
        ax.set_title(f"({chr(97 + index)}) {text}", loc="left", pad=3, color=INK)


def legend(ax: Any, **kwargs: Any) -> None:
    ax.legend(frameon=False, **kwargs)

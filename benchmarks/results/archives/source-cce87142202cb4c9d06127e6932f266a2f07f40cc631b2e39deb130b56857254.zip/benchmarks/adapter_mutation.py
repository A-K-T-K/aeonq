"""Mutation analysis: does the conformance battery detect seeded adapter bugs?

Every mutant in ``aeonq.conformance.mutation.MUTANTS`` is injected into each
SDK adapter, and the full battery is run. A mutant is *killed* when at least
one check fails. Rows for the unmutated adapters ("none") are the false-alarm
control: a correct adapter must pass every check. Per-level failure counts
show which kind of check exposes which kind of bug.
"""

import csv
from datetime import datetime, timezone
import json
from pathlib import Path
from time import perf_counter

from aeonq.adapters.cirq import CirqAdapter
from aeonq.adapters.pennylane import PennyLaneAdapter
from aeonq.adapters.qiskit import QiskitAdapter
from aeonq.adapters.qsharp import QSharpAdapter
from aeonq.benchmarks.runner import environment_record
from aeonq.conformance.battery import run_battery
from aeonq.conformance.mutation import MUTANTS, MutantAdapter

LEVELS = ("operator", "measurement", "sampling")


def run(output: Path) -> list[dict]:
    adapters = {
        "qiskit": QiskitAdapter,
        "cirq": CirqAdapter,
        "pennylane": PennyLaneAdapter,
        "qsharp": QSharpAdapter,
    }
    rows = []
    for sdk, factory in adapters.items():
        for mutant in ("none", *MUTANTS):
            adapter = (
                factory() if mutant == "none" else MutantAdapter(factory(), mutant)
            )
            started = perf_counter()
            results = run_battery(adapter)
            failures = {
                level: sum(r.passed is False for r in results if r.level == level)
                for level in LEVELS
            }
            rows.append(
                {
                    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                    "sdk": sdk,
                    "mutant": mutant,
                    "description": MUTANTS.get(mutant, "unmutated adapter (control)"),
                    "checks": len(results),
                    "failed_checks": sum(failures.values()),
                    "unsupported_checks": sum(r.passed is None for r in results),
                    **{f"failed_{level}": failures[level] for level in LEVELS},
                    "killed": sum(failures.values()) > 0,
                    "first_failure": next(
                        (
                            f"{r.level}:{r.case}:{r.check}"
                            for r in results
                            if r.passed is False
                        ),
                        "",
                    ),
                    "seconds": perf_counter() - started,
                }
            )
            print(sdk, mutant, rows[-1]["killed"], failures, flush=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    output.with_suffix(".environment.json").write_text(
        json.dumps(environment_record(), indent=2), encoding="utf-8"
    )
    return rows


def estimator_impact(output: Path, *, repetitions: int = 20) -> list[dict]:
    """Does each fault change what the estimators report?

    Faults invisible to sampling can still matter: canonical QAE interferes
    controlled Grover powers, so a relative phase error shifts its estimate
    even when A·Q^k sampling is unchanged. Cirq is used because it is fast;
    the battery shows every SDK is affected identically.
    """
    from aeonq import estimate
    from aeonq.benchmarks.problems import bernoulli, lognormal_tail, strike_for_index

    cases = (
        bernoulli(0.3),
        lognormal_tail(2, strike_for_index(2, 2), objective_ancilla=True),
    )
    methods = {
        "iqae": {"epsilon": 0.01, "max_power": 8},
        "canonical_qae": {"evaluation_qubits": 4, "shots": 256},
    }
    rows = []
    for mutant in ("none", *MUTANTS):
        adapter = (
            CirqAdapter() if mutant == "none" else MutantAdapter(CirqAdapter(), mutant)
        )
        for case in cases:
            for method, options in methods.items():
                errors, crashes = [], 0
                for trial in range(repetitions):
                    try:
                        result = estimate(
                            case.problem,
                            algorithm=method,
                            backend=adapter,
                            seed=4001 + 7919 * trial,
                            **options,
                        )
                        errors.append(abs(result.estimate - case.a_true))
                    except Exception:
                        crashes += 1
                rows.append(
                    {
                        "sdk": "cirq",
                        "mutant": mutant,
                        "case_id": case.case_id,
                        "a_true": case.a_true,
                        "method": method,
                        "repetitions": repetitions,
                        "crashes": crashes,
                        "mean_abs_error": sum(errors) / len(errors) if errors else None,
                        "max_abs_error": max(errors) if errors else None,
                    }
                )
                print(
                    mutant, case.case_id, method, rows[-1]["mean_abs_error"], flush=True
                )
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return rows


if __name__ == "__main__":
    run(Path("paper_artifacts/raw_results/adapter_mutation.csv"))
    estimator_impact(Path("paper_artifacts/raw_results/adapter_mutation_impact.csv"))
